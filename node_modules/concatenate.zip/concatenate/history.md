
0.0.2 / 2017-01-22
==================

  * Point the 'globs' dependency to NPM instead of github
  * add repo to package.json

0.0.1 / 2013-04-29
==================

  * Initial release
